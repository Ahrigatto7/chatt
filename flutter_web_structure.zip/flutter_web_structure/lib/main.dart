
import 'package:flutter/material.dart';

void main() {
  runApp(MyWebApp());
}

class MyWebApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Web Example',
      home: Scaffold(
        appBar: AppBar(title: Text('Flutter Web 실행 예시')),
        body: Center(
          child: Text('🎉 웹에서 Flutter 앱이 실행됩니다!'),
        ),
      ),
    );
  }
}
